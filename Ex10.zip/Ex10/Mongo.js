const mongoose = require('mongoose');
// const Person = require('./models/person');
// Define a schema for the patient details
const patientSchema = new mongoose.Schema({
  name: String,
  age: Number,
  id: Number,
  gender: String,
  address: String,
  maritalStatus: String,
  dateOfVisit: Date,
});

// Define a model for the patient details using the schema
const PatientDetails = mongoose.model('patient_details', patientSchema);

// Connect to the MongoDB database
mongoose.connect('mongodb://localhost/Patient', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to database!');

    //Adding new Patient
    const newPatient = new PatientDetails({
      name: 'Alice',
      age: 25,
      gender: 'Female',
      diagnosis: 'Leukemia',
    });

    newPatient.save()
      .then((result) => {
        console.log('New patient added:', result);
      })
      .catch((error) => {
        console.error('Error adding patient:', error);
      });

    //Deleting One Document
    PatientDetails.findOneAndDelete({ name: 'Sumon' })
      .then((result) => {
        console.log('Document deleted:', result);
      })
      .catch((error) => {
        console.error('Error deleting document:', error);
      });


    // Update a document
    PatientDetails.findOneAndUpdate({ name: 'Alice' }, { age: 30 }, { new: true })
      .then((result) => {
        console.log('Document updated:', result);
      })
      .catch((error) => {
        console.error('Error updating document:', error);
      });

    //Query
    PatientDetails.findOne({ name: 'Sumon' })
      .then((patient) => {
        console.log('Patient details:', patient);
      })
      .catch((err) => {
        console.error('Error querying for patient:', err);

      });
  })





  .catch((error) => {
    console.error('Error connecting to database:', error);
  });
