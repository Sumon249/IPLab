import { Link } from "react-router-dom";
import  "./MainNavigation.css"
function MainNavigation() {
    return (
        <nav>
        <div className = "logo-div">
            <img className="logo" src="/network-logo.png" alt="" />
        </div>
        <div className = "navbar-right">
            <ul className = "nav-elements">
                <li>
                    <Link to="/"> Home</Link>
                </li>
                <li>
                    <Link to="/callForPapers">Call For Papers</Link>
                </li>
                <li>
                    <Link to="/committee">Commitee</Link>
                </li>
                <li>
                    <Link to="/importantDates">Important dates</Link>
                </li>
                <li>
                    <Link to="/workshops">Workshops</Link>
                </li>
                <li>
                    <Link to="/regsitration">Registration</Link>
                </li>
                <li>
                    <Link to="/contact">Contact</Link>
                </li>
            </ul>
        </div>
    </nav>
    );
}

export default MainNavigation;