import './App.css';
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Root from './pages/Root';
import HomePage from './pages/Home';
import CommitteePage from './pages/Committee';
import RegistrationPage from './pages/Registration';
import WorkshopsPage from './pages/Workshops';
import ImportantDatespage from './pages/ImportantDates';
import ContactPage from './pages/Contact';
import CallForPapersPage from './pages/CallForPapers';

function App() {

  const router = createBrowserRouter([
    { path: '/',
      element: <Root />,
      children: [
        {path: '/', element: <HomePage />},
        {path: '/committee', element: <CommitteePage />},
        {path: '/regsitration', element: <RegistrationPage />},
        {path: '/workshops', element: <WorkshopsPage />},
        {path: '/importantDates', element: <ImportantDatespage />}, 
        {path: '/contact', element: <ContactPage />}, 
        {path: '/callForPapers', element: <CallForPapersPage />}, 
        // {path: '/products', element: <ProductsPage />}
      ]
    },
  ]);

  return (
    <div className="App">
      <RouterProvider router = {router}></RouterProvider>
    </div>
  );
}

export default App;
