import React from 'react'

const CallForPapersPage = () => {
  return (
    <>
      <main className="call-for-paper">
        <div className="paper-card">
          <h2 className="call-heading">CALL FOR PAPERS</h2>
          <div className="call-text">

            <p>We invite high-quality submissions describing original and unpublished work
              for the conference. At least one author should register for the conference. Though the theme of this
              conference is Computational Intelligence in Data Science and Knowledge Management we also solicit
              papers from cutting edge technologies like IoT, Cyber Security and Software Defined Networks.
              Machine learning deliver insights hidden in data for rapid, automated responses and improved
              decision making. Machine learning for IoT can be used to project future trends, detect anomalies,
              and augment intelligence by ingesting image, video and audio. Edge computing allows the deployment
              of light weight devices to process data collected from IoT sensors. Machine learning aids cyber
              security systems to analyze patterns and helps to adapt the dynamic behavior to defend against
              attacks. Modern networking paradigms like Software Defined Networking allows high degree of
              programmability by decoupling control plane from the data plane. Cyber security can be measured
              under 5 themes - firewalls, secure configuration, user access control, malware protection and patch
              management.
              Accepted papers that are presented at the conference will be published in theScopus Indexed Springer
              IFIP AICT (Advances in Information and Communication Technology) series.
              Each paper will receive at least three reviews. At least one author of each accepted paper must
              register by the early registration date indicated on the conference website and present the paper
            </p>
            <br />
            <h3>Submission guidelines</h3>
            <p>Authors must follow the formatting instructions. For camera-ready papers, use Latex or Word style
              Author's instruction page.
              Submission Link: Online Conference Service (Springer)
              <br />
              Authors are requested to make use of below templates for preparing the manuscript
              <br />
              <strong>LaTex</strong>
              <br />
              <strong> MS-Word</strong>
            </p>
          </div>
        </div>

      </main>
      <footer>
        <div>
          <h4>Contact us</h4>
          <p><a href="www.facebook.com">Facebook</a></p>
          <p><a href="www.linkedin.com">LinkedIn</a></p>
          <p><a href="www.instagram.com">Instagram</a></p>
        </div>
        <div>
          <h4>UCS1611</h4>
          <p>Internet Programming Lab</p>
          <p>Sumon Kumar</p>
          <p>205001114</p>
        </div>
        <div>
          <h4>Address</h4>
          <p>SSN College of Engineering </p>
          <p> Chengalpattu</p>
          <p> Tamil Nadu</p>
        </div>
      </footer>
    </>
  )
}

export default CallForPapersPage