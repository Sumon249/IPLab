import React from 'react'

const ImportantDatespage = () => {
  return (
    <>
    <main className="important-dates">
        <h3 style={{textAlign:"center"}}>IMPORTANT DATES</h3>
        <div className="form-card">
            <ul className="dates">
                <li>Paper submission deadline: <strong>March 1 2023</strong></li>
                <li>Notification of Acceptance: <strong>March 5 2023</strong></li>
                <li>Camera Ready Copy & Registration: <strong>March 7 2023</strong></li>
                <li>Pre-Conference Workshop: <strong>March 9 2023</strong></li>
                <li>Conference: <strong>March 10 2023</strong></li>
            </ul>
        </div>
    </main>
    <footer>
        <div>
            <h4>Contact us</h4>
            <p><a href="https://www.facebook.com/">Facebook</a></p>
            <p><a href="www.linkedin.com">LinkedIn</a></p>
            <p><a href="www.instagram.com">Instagram</a></p>
        </div>
        <div>
            <h4>UCS1611</h4>
            <p>Internet Programming Lab</p>
            <p>Sumon Kumar</p>
            <p>205001114</p>
        </div>
        <div>
            <h4>Address</h4>
            <p>SSN College of Engineering </p>
            <p> Chengalpattu</p>
            <p> Tamil Nadu</p>
        </div>
    </footer>
    </>
  )
}

export default ImportantDatespage