import React from 'react'

const ContactPage = () => {
    return (
        <>
            <main className="contacts">

                <div className="contact-card">
                    <h2 className="contact-heading">Technical Commitee</h2>
                    <p className="contact-name">Alicia <span className="contact-number">
                        Ph:98018400128</span></p>
                    <p className="contact-name">Veronica <span className="contact-number">Ph:849208142</span></p>
                    <p className="contact-name">Pattrick<span className="contact-number">Ph:904820184</span></p>
                    <p className="contact-name" >Joel <span className="contact-number">Ph:893829183</span>
                    </p>
                </div>
                <div className="contact-card">
                    <h2 className="contact-heading"> Non-Technical Commitee</h2>
                    <p className="contact-name">Matthew <span className="contact-number">Ph:98018400128
                    </span></p>
                    <p className="contact-name">Jane <span className="contact-number">Ph:849208142</span>
                    </p>
                    <p className="contact-name">Jasmine <span className="contact-number">Ph:904820184</span></p>
                    <p className="contact-name">Adam <span className="contact-number">Ph:893829183</span>
                    </p>
                </div>

            </main>
            <footer>
                <div>
                    <h4>Contact us</h4>
                    <p><a href="www.facebook.com">Facebook</a></p>
                    <p><a href="www.linkedin.com">LinkedIn</a></p>
                    <p><a href="www.instagram.com">Instagram</a></p>
                </div>
                <div>
                    <h4>UCS1611</h4>
                    <p>Internet Programming Lab</p>
                    <p>Sumon Kumar</p>
                    <p>205001114</p>
                </div>
                <div>
                    <h4>Address</h4>
                    <p>SSN College of Engineering </p>
                    <p> Chengalpattu</p>
                    <p> Tamil Nadu</p>
                </div>
            </footer>
        </>
    )
}

export default ContactPage