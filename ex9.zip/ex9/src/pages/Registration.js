import React from 'react'

const RegistrationPage = () => {
  return (
    <>
     <main>
            <h1 class = "registration-heading">Welcome to the World Wide Web Conference 2023</h1>

        <div class="form-card">

            <div style={{color: "white"}}>
                <form class = "registration-form" action="">
                    <label for="">Name
                        <input type="text" name="" id="" />
                    </label>

                    <label for="">Password
                        <input type="password" name="" id="" />
                    </label>

                    <label for="">Email
                        <input type="email" name="" id="" />
                    </label>

                    <label for="">Date of Birth
                        <input type="date" name="" id="" />
                    </label>

                    <label for="">Address
                        <input type="text" name="" id="" />
                    </label>

                    <button class = "submit-btn" type="submit">SUBMIT</button>
                </form>
            </div>
        </div>

    </main>
    <footer>
        <div>
            <h4>Contact us</h4>
            <p><a href="www.facebook.com">Facebook</a></p>
            <p><a href="www.linkedin.com">LinkedIn</a></p>
            <p><a href="www.instagram.com">Instagram</a></p>
        </div>
        <div>
            <h4>UCS1611</h4>
            <p>Internet Programming Lab</p>
            <p>Sumon Kumar</p>
            <p>205001114</p>
        </div>
        <div>
            <h4>Address</h4>
            <p>SSN College of Engineering </p>
            <p> Chengalpattu</p>
            <p> Tamil Nadu</p>
        </div>
        </footer>
        </>
  )
}

export default RegistrationPage