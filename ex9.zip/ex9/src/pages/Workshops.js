import React from 'react'

const WorkshopsPage = () => {
  return (
    <>
     <main>
            <table
            className = "workshop-table">
                <thead>
                    <tr style={{backgroundColor: "rgba(16, 66, 127, 0.3)"}}>
                        <th colspan="3">
                            <h2>WORKSHOPS</h2>
                        </th>
                    </tr>
                </thead>
                <tr>
                    <th>
                        <h3 className = "workshop-title">Worskhop Name</h3>
                    </th>
                    <th>
                        <h3 className = "workshop-title">Start Date</h3>
                    </th>
                    <th>
                        <h3 className = "workshop-title">End Date</h3>
                    </th>
                </tr>
                <tr>
                    <td>
                        Pre-Conference workshop
                    </td>
                    <td>
                        9/3/2023
                    </td>
                    <td>
                        10/3/2023
                    </td>
                </tr>
                <td>
                    Advanced Javascript Concepts
                </td>
                <td>
                    10/3/2023
                </td>
                <td>
                    13/3/2023
                </td>
                <tr>
                    <td>
                        React, Angular and Vue. Which ones better?
                    </td>
                    <td>
                        11/3/2023
                    </td>
                    <td>
                        13/3/2023
                    </td>
                </tr>
                <tr>
                    <td>
                        CSS Tricks to make flawless designs
                    </td>
                    <td>
                        12/3/2023
                    </td>
                    <td>
                        13/3/2023
                    </td>
                </tr>
            </table>
    </main>
    <footer>
        <div>
            <h4>Contact us</h4>
            <p><a href="www.facebook.com">Facebook</a></p>
            <p><a href="www.linkedin.com">LinkedIn</a></p>
            <p><a href="www.instagram.com">Instagram</a></p>
        </div>
        <div>
            <h4>UCS1611</h4>
            <p>Internet Programming Lab</p>
            <p>Sumon Kumar</p>
            <p>205001114</p>
        </div>
        <div>
            <h4>Address</h4>
            <p>SSN College of Engineering </p>
            <p> Chengalpattu</p>
            <p> Tamil Nadu</p>
        </div>
        </footer>
        </>
  )
}

export default WorkshopsPage