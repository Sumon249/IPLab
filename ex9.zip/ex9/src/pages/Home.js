import React from 'react'

const HomePage = () => {
  return (
    <>
    <main>
            <div className = "main-text">
                <h1>World Wide Web Conference 2023</h1>
                <p>
                    Seventh International Conference on Web Technology and Innovation
                </p>
                <button className = "registration-btn" type="">
                    <a href="registration.html">
                        Register Now!
                    </a>
                </button>
            </div>

    </main>
    <footer className = "home-footer">
        <div>
            <h4>Contact us</h4>
            <p><a href="www.facebook.com">Facebook</a></p>
            <p><a href="www.linkedin.com">LinkedIn</a></p>
            <p><a href="www.instagram.com">Instagram</a></p>
        </div>
        <div>
            <h4>UCS1611</h4>
            <p>Internet Programming Lab</p>
            <p>Sumon Kumar</p>
            <p>205001114</p>
        </div>
        <div>
            <h4>Address</h4>
            <p>SSN College of Engineering </p>
            <p> Chengalpattu</p>
            <p> Tamil Nadu</p>
        </div>

    </footer>
    </>
  )
}

export default HomePage