import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
 
public class AjaxServlet extends HttpServlet{
		// JDBC driver name and database URL
      static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
      static final String DB_URL="jdbc:mysql://localhost:3306/country_names";


      static final String USER = "root";
      static final String PASS = "crocs249";
	  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
 
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title = "Database Result";
		String docType =
         "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";


        String CountryLetters=request.getParameter("Letters");

		out.println(docType +"<html><head><link rel='stylesheet' href='styles.css'></head><body><div class='box'>");
		try {

			Class.forName(JDBC_DRIVER);

			Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = conn.createStatement();
			String sql;
			sql = "SELECT name FROM Countries WHERE name LIKE '"+CountryLetters+"%'";
			ResultSet rs = stmt.executeQuery(sql);
            if(rs.next()) {
				out.print("HEASAD");
                String country=rs.getString("name");
                out.print("<p>"+country+"</p>"); 
                while(rs.next()){
                    country=rs.getString("name");
                    out.print("<p>"+country+"</p>");
                }
            }
            else{
            }
			out.println("</div></body></html></body></html>");

			rs.close();
			stmt.close();
			conn.close();
		} 
		catch(SQLException se) {
         se.printStackTrace();
		} 
		catch(Exception e) {
         e.printStackTrace();
		} 
		finally {

		}
   }
} 